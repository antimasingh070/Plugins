import{i}from"./ModalsView.js";import{_ as m}from"./App.vue_vue_type_script_setup_true_lang.js";/* empty css                          */i(m);
