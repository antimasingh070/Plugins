import{A as m}from"./ModalsView.js";/* empty css                          */export{m as default};
