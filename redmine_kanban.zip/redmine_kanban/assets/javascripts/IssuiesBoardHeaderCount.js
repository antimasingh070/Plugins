import{a2 as m}from"./ModalsView.js";/* empty css                          */export{m as default};
