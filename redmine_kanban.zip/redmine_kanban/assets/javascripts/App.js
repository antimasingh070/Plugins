import{_ as o}from"./App.vue_vue_type_script_setup_true_lang.js";import"./ModalsView.js";/* empty css                          */export{o as default};
