function e(n){return n.id?`<a href="/users/${n.id}">${n.name}</a>`:n.name}export{e as l};
